'use client';

import type { Field, QuestionnaireProps } from './types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { formSchema } from './formSchema';
import Review from './Review';
import Sidebar from './Sidebar';
import StepForm from './StepForm';
import ThankYou from './ThankYou';

export default function Questionnaire({ steps }: QuestionnaireProps) {
  const searchParams = useSearchParams();
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [submitted, setSubmitted] = useState(false);

  const {
    handleSubmit,
    control,
    formState: { errors },
    setValue,
    getValues,
    register,
    trigger,
  } = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: 'Shahbaz',
      lastName: 'Ali Khan Imrani',
      email: 'ishahbaz.pk@gmail.com',
      operatingSystem: 'windows',

      outgoingInvoices: 'Yes',
      incomingInvoices: 'Yes',
      recurringBills: 'Yes',

      dynamicCheckboxDropdown: ['purchaseContract', 'loanAgreement'],

      ibans: ['DE89 3704 0044 0532 0130 00'],
      bankFileObtain: 'Yes',

      payrollAccounting: 'Yes',
      agmSettlements: 'Yes',

      // person: [
      //   {
      //     firstName: 'Shahbaz',
      //     lastName: 'Ali Khan Imrani',
      //   },
      //   {
      //     firstName: 'Ali',
      //     lastName: 'Khan',
      //   },
      // ],

      // creditCards: ['4220700012952405'],
      ccFileObtain: 'No',

      paypal: 'Yes',
      cashDesk: 'Yes',
      inventory: 'Yes',
    },
  });

  const onSubmit = async (data: any) => {
    try {
      console.error('Form data:', data);
      const clientId = searchParams.get('clientId');
      const companyName = searchParams.get('companyName');
      if (!clientId || !companyName) {
        console.error('Missing clientId or companyName in search params');
        return;
      }
      data.clientId = clientId;
      data.companyName = companyName;
      data.ibans = data.ibans.map((iban: string) => iban.replace(/\s+/g, ''));
      data.creditCards = data.creditCards.map((card: string) => card.replace(/\s+/g, ''));
      data.dynamicCheckboxDropdown = data.dynamicCheckboxDropdown.map((cat: string) => cat.replace(/\s+/g, ''));
      const response = await fetch('/api/questionnaire', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (response.ok) {
        setSubmitted(true);
        // Optionally redirect or show success
      } else {
        console.error('Error:', result.message);
      }
    } catch (err) {
      console.error('Unexpected error:', err);
    }
  };

  const nextStep = async () => {
    const valid = await trigger(steps[currentStep]?.fields.map((f: Field) => f.name) as (keyof typeof formSchema.shape)[]); // Validate current fields
    if (valid) {
      // const newStep = currentStep + 1;
      // setCurrentStep(newStep);
      setCurrentStep(12);

      if (!completedSteps.includes(currentStep)) {
        setCompletedSteps(prev => [...prev, currentStep]);
      }
    }
  };

  const previousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleStepClick = (index: number) => {
    if (completedSteps.includes(index) || index === currentStep) {
      setCurrentStep(index);
    }
  };

  if (submitted) {
    return <ThankYou />;
  }

  return (
    <div className="flex space-x-6 py-8">
      <Sidebar
        currentStep={currentStep}
        steps={steps}
        completedSteps={completedSteps}
        onStepClick={handleStepClick}
      />

      <div className="flex-1 bg-white p-6 rounded-lg shadow-md">
        {currentStep <= steps.length + 1 && steps[currentStep]
          ? (
              <StepForm
                step={steps[currentStep]}
                control={control}
                errors={errors}
                onNext={nextStep}
                onPrevious={previousStep}
                setValue={setValue}
                register={register}
              />
            )
          : (
              <Review data={getValues()} steps={steps} onSubmit={handleSubmit(onSubmit)} />
            )}
      </div>
    </div>
  );
}
