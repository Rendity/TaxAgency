import type { StepFormProps } from './types';
import { Controller } from 'react-hook-form';
import FieldRenderer from './FieldRenderer'; // Correct usage

export default function StepForm({
  step,
  control,
  errors,
  onNext,
  onPrevious,
  register,
}: StepFormProps) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-2">{step.title}</h2>
        <div
          className="text-sm text-gray-600"
          // eslint-disable-next-line react-dom/no-dangerously-set-innerhtml
          dangerouslySetInnerHTML={{ __html: step.description }}
        />
      </div>

      <div className="space-y-6">
        {step.fields.map(field => (
          <div key={field.name} className="flex flex-col space-y-1">
            {field.description && field.type === 'radio' && field.name === 'operatingSystem' && (
              <div
                className="text-sm text-gray-600"
                // eslint-disable-next-line react-dom/no-dangerously-set-innerhtml
                dangerouslySetInnerHTML={{ __html: field.description }}
              />
            )}
            {(field.description && (field.name === 'incomingInvoices' || field.name === 'recurringBills')) && (
              <>
                <h2 className="text-xl font-bold mb-0">{field.label}</h2>
                <div
                  className="text-sm text-gray-600"
                  // eslint-disable-next-line react-dom/no-dangerously-set-innerhtml
                  dangerouslySetInnerHTML={{ __html: field.description }}
                />
              </>
            )}
            <Controller
              control={control}
              name={field.name}
              rules={field.validation}
              render={({ field: controllerField }) => (
                <>
                  <FieldRenderer
                    field={field}
                    value={controllerField.value}
                    // control={control}
                    register={register}
                    errors={errors}
                    onChange={controllerField.onChange}
                  />
                  {errors[field.name] && (
                    <span className="text-sm text-red-500">{errors[field.name]?.message}</span>
                  )}
                </>
              )}
            />
          </div>
        ))}
      </div>

      <div className="flex justify-between pt-8">
        <button
          type="button"
          onClick={onPrevious}
          className="px-6 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400 transition"
        >
          Back
        </button>

        <button
          type="button"
          onClick={onNext}
          className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition"
        >
          Next
        </button>
      </div>
    </div>
  );
}
