import type { RadioType } from '../types';

export const RadioField = (radioField: RadioType) => {
  return (
    <div className="flex items-center pr-5 ps-5 border border-gray-200 rounded-sm dark:border-gray-700">
      <input
        type="radio"
        id={`${radioField.name}-${radioField.value}`}
        checked={radioField.checked}
        value={radioField.value}
        name={radioField.name}
        onChange={() => radioField.onChange(radioField.value)}
        className="w-6 h-6 text-blue-600 bg-gray-100 border-gray-300 rounded-full focus:outline-none focus:ring-0 dark:bg-gray-700 dark:border-gray-600"
      />
      <label htmlFor={`${radioField.name}-${radioField.value}`} className="w-full py-4 ms-2 text-lg font-medium text-gray-900 dark:text-gray-300">{radioField.label}</label>
    </div>
  );
};

export default RadioField;
