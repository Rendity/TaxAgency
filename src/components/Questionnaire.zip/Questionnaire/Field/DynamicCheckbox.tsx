import type { FieldRendererProps } from '../types';
import { useEffect, useState } from 'react';

export const DynamicCheckboxDropdownField = ({ field, value, onChange }: FieldRendererProps) => {
  const fixedOptions = field.options || []; // [{ label, value }]
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const extraOptions = field.extraOptions || []; // [{ label, value }]

  const [selectedValues, setSelectedValues] = useState<string[]>(() => {
    return Array.isArray(value) ? value : []; // ⬅️ only trust passed value
  });

  const [availableExtraOptions, setAvailableExtraOptions] = useState(() => {
    return extraOptions.filter(opt => !selectedValues.includes(opt.value));
  });

  // 🛠 Sync internal state if external `value` changes
  useEffect(() => {
    if (Array.isArray(value)) {
      // eslint-disable-next-line react-hooks-extra/no-direct-set-state-in-use-effect
      setSelectedValues(value);
      // eslint-disable-next-line react-hooks-extra/no-direct-set-state-in-use-effect
      setAvailableExtraOptions(
        extraOptions.filter(opt => !value.includes(opt.value)),
      );
    }
  }, [value, extraOptions]);

  const handleSelect = (selectedValue: string) => {
    const updatedSelected = [...selectedValues, selectedValue];
    setSelectedValues(updatedSelected);
    setAvailableExtraOptions(prev => prev.filter(opt => opt.value !== selectedValue));
    onChange(updatedSelected);
  };

  const handleCheckboxChange = (optionValue: string) => {
    let updatedSelected;
    if (selectedValues.includes(optionValue)) {
      // uncheck
      updatedSelected = selectedValues.filter(val => val !== optionValue);
      // Put back into available extra options if it's extra
      if (extraOptions.some(opt => opt.value === optionValue)) {
        const restoredOption = extraOptions.find(opt => opt.value === optionValue);
        if (restoredOption) {
          setAvailableExtraOptions(prev => [...prev, restoredOption]);
        }
      }
    } else {
      // check
      updatedSelected = [...selectedValues, optionValue];
      // Remove from available if extra
      setAvailableExtraOptions(prev => prev.filter(opt => opt.value !== optionValue));
    }
    setSelectedValues(updatedSelected);
    onChange(updatedSelected);
  };

  return (
    <div className="space-y-4">
      {/* Checkboxes */}
      <div className="space-y-2">
        {[
          ...fixedOptions,
          ...extraOptions.filter(opt => selectedValues.includes(opt.value)),
        ].map(option => (
          <div key={option.value} className="flex items-center space-x-2">
            <input
              type="checkbox"
              id={option.label}
              checked={selectedValues.includes(option.value)}
              onChange={() => handleCheckboxChange(option.value)}
            />
            <label htmlFor={option.label}>{option.label}</label>
          </div>
        ))}
      </div>

      {/* Dropdown */}
      {availableExtraOptions.length > 0 && (
        <select
          value=""
          onChange={(e) => {
            const val = e.target.value;
            if (val) {
              handleSelect(val); // select the item
            // ✅ automatically blank again (because value="" always)
            }
          }}
          className="p-2 border rounded-md"
        >
          <option value="" disabled>
            {field.label || 'Add more options...'}
          </option>
          {availableExtraOptions.map(opt => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      )}
    </div>
  );
};

export default DynamicCheckboxDropdownField;
