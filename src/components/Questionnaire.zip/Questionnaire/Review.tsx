// src/components/Questionnaire/Review.tsx

import type { FC } from 'react';
import type { ReviewProps } from './types';

const Review: FC<ReviewProps> = ({ data, steps, onSubmit }) => {
  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-semibold">Review Your Answers</h3>

      <div className="space-y-8">
        {steps.map((step, stepIdx) => (
          // eslint-disable-next-line react/no-array-index-key
          <div key={stepIdx} className="space-y-4">
            <h4 className="text-xl font-semibold text-blue-700">{step.title}</h4>

            <div className="space-y-2">
              {step.fields.map((field) => {
                const userValue = data[field.name];

                if (userValue === undefined || userValue === null) {
                  return null; // skip empty answers
                }

                let displayValue;

                // Handle special types like arrays
                if (Array.isArray(userValue)) {
                  displayValue = userValue.join(', ');
                } else if (typeof userValue === 'boolean') {
                  displayValue = userValue ? 'Yes' : 'No';
                } else {
                  displayValue = String(userValue);
                }

                return (
                  <div key={field.name} className="flex justify-between items-center border-b pb-2">
                    <span className="text-gray-700 font-medium">{field.label}</span>
                    <span className="text-gray-500">{displayValue}</span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <button
        type="button"
        onClick={() => onSubmit(data)}
        className="w-full py-3 mt-8 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition"
      >
        Submit
      </button>
    </div>
  );
};

export default Review;
